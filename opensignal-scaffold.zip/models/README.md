# ONNX Models

Place actual ONNX artifacts in this directory with exactly these names:

- `candle_detector.onnx`
- `liquidity_sweep.onnx`
- `structure_detector.onnx`
- `trend_classifier.onnx`

Both the Kotlin `ai-inference` module and Python `ai-service` load these files directly using ONNX Runtime.

Model loading is strict and will fail if files are missing or invalid.
