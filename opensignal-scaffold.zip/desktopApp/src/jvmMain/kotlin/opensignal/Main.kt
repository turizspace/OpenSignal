package opensignal

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Window
import androidx.compose.ui.window.application
import java.io.File
import java.nio.file.Files
import kotlinx.coroutines.launch
import opensignal.ai.pipeline.OpenSignalVisionAnalyzer
import opensignal.ai.pipeline.RuleBasedFundamentalAnalyzer
import opensignal.blossom.nip96_client.Nip96ServerConfig
import opensignal.blossom.upload_service.BlossomUploadService
import opensignal.charts.TradingChart
import opensignal.domain.AnalyzeScreenshotUseCase
import opensignal.domain.OpenSignalController
import opensignal.domain.ScreenshotUploader
import opensignal.domain.parseTimeframeOrDefault
import opensignal.domain.pseudoImageBytes
import opensignal.models.ScreenshotPayload
import opensignal.nostr.NostrClient
import opensignal.settings.InMemorySettingsRepository
import opensignal.settings.SettingsRepository
import opensignal.settings.ThemeMode

fun main() = application {
    val settingsRepository = remember { InMemorySettingsRepository() }
    val nostrClient = remember { NostrClient() }
    val screenshotUploader = remember { SettingsAwareUploader(settingsRepository) }
    val analyzer = remember { OpenSignalVisionAnalyzer() }
    val fundamental = remember { RuleBasedFundamentalAnalyzer() }
    val useCase = remember {
        AnalyzeScreenshotUseCase(
            screenshotUploader = screenshotUploader,
            chartVisionAnalyzer = analyzer,
            fundamentalAnalyzer = fundamental,
            signalPublisher = nostrClient
        )
    }
    val controller = remember {
        OpenSignalController(
            authGateway = nostrClient,
            analyzeUseCase = useCase,
            settingsRepository = settingsRepository
        )
    }

    val settings by settingsRepository.settings.collectAsState()
    val colorScheme = when (settings.themeMode) {
        ThemeMode.DARK, ThemeMode.HIGH_CONTRAST -> darkColorScheme(
            primary = androidx.compose.ui.graphics.Color(0xFF4DD0E1),
            secondary = androidx.compose.ui.graphics.Color(0xFFFFB74D),
            background = androidx.compose.ui.graphics.Color(0xFF0E1116)
        )

        else -> lightColorScheme(
            primary = androidx.compose.ui.graphics.Color(0xFF005F73),
            secondary = androidx.compose.ui.graphics.Color(0xFFCA6702),
            background = androidx.compose.ui.graphics.Color(0xFFF2F7FA)
        )
    }

    Window(
        onCloseRequest = ::exitApplication,
        title = "OpenSignal Trading Copilot"
    ) {
        MaterialTheme(colorScheme = colorScheme) {
            DesktopCopilotScreen(
                controller = controller,
                settingsRepository = settingsRepository
            )
        }
    }
}

private class SettingsAwareUploader(
    private val settingsRepository: SettingsRepository
) : ScreenshotUploader {
    override suspend fun upload(payload: ScreenshotPayload) = BlossomUploadService(
        Nip96ServerConfig(baseUrl = settingsRepository.settings.value.blossomServer)
    ).upload(payload)
}

@Composable
private fun DesktopCopilotScreen(
    controller: OpenSignalController,
    settingsRepository: SettingsRepository
) {
    val scope = rememberCoroutineScope()
    val state by controller.state.collectAsState()
    val settings by settingsRepository.settings.collectAsState()

    var nsec by remember { mutableStateOf("") }
    var signerUri by remember { mutableStateOf("bunker://nostr-signer") }
    var symbol by remember { mutableStateOf("BTCUSDT") }
    var timeframe by remember { mutableStateOf("H1") }
    var screenshotPath by remember { mutableStateOf("") }
    var accountBalance by remember { mutableStateOf("10000") }
    var riskPercent by remember { mutableStateOf("1") }
    var leverage by remember { mutableStateOf("3") }
    var context by remember { mutableStateOf("Looking for intraday setup") }
    var relayInput by remember { mutableStateOf(settings.preferredRelays.joinToString(",")) }
    var blossomServer by remember { mutableStateOf(settings.blossomServer) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("OpenSignal Trading Copilot", style = MaterialTheme.typography.headlineSmall)

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Authentication", style = MaterialTheme.typography.titleMedium)
                OutlinedTextField(
                    value = nsec,
                    onValueChange = { nsec = it },
                    label = { Text("Nostr nsec") },
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = {
                        scope.launch {
                            controller.loginWithNsec(
                                nsec = nsec,
                                relayHint = settings.preferredRelays.firstOrNull()
                            )
                        }
                    }) {
                        Text("Login with nsec")
                    }
                }
                OutlinedTextField(
                    value = signerUri,
                    onValueChange = { signerUri = it },
                    label = { Text("External signer URI") },
                    modifier = Modifier.fillMaxWidth()
                )
                Button(onClick = {
                    scope.launch {
                        controller.loginWithExternalSigner(signerUri)
                    }
                }) {
                    Text("Login with external signer")
                }
                Text("Session: ${state.authSession?.pubkey ?: "Not authenticated"}")
            }
        }

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Screenshot Analysis", style = MaterialTheme.typography.titleMedium)
                OutlinedTextField(
                    value = symbol,
                    onValueChange = { symbol = it },
                    label = { Text("Symbol") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = timeframe,
                    onValueChange = { timeframe = it },
                    label = { Text("Timeframe (M15/H1/H4)") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = screenshotPath,
                    onValueChange = { screenshotPath = it },
                    label = { Text("Screenshot path") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = context,
                    onValueChange = { context = it },
                    label = { Text("User context") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = accountBalance,
                    onValueChange = { accountBalance = it },
                    label = { Text("Balance") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = riskPercent,
                    onValueChange = { riskPercent = it },
                    label = { Text("Risk %") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = leverage,
                    onValueChange = { leverage = it },
                    label = { Text("Leverage") },
                    modifier = Modifier.fillMaxWidth()
                )

                Button(onClick = {
                    scope.launch {
                        val payload = loadScreenshotPayload(screenshotPath)
                        controller.analyzeScreenshot(
                            symbol = symbol,
                            timeframe = parseTimeframeOrDefault(timeframe),
                            screenshot = payload,
                            accountBalance = accountBalance.toDoubleOrNull() ?: 10_000.0,
                            riskPercent = riskPercent.toDoubleOrNull() ?: 1.0,
                            leverage = leverage.toDoubleOrNull() ?: 3.0,
                            userContext = context
                        )
                    }
                }) {
                    Text(if (state.isLoading) "Analyzing..." else "Analyze & Publish")
                }
                state.error?.let { Text("Error: $it") }
            }
        }

        state.latestAnalysis?.let { analysis ->
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("AI Analysis", style = MaterialTheme.typography.titleMedium)
                    TradingChart(
                        technical = analysis.signal.technical,
                        tradePlan = analysis.signal.tradePlan,
                        showLiquidity = settings.showLiquidityZones,
                        showStructure = settings.showStructureBreaks,
                        modifier = Modifier.fillMaxWidth()
                    )
                    HorizontalDivider()
                    Text("Technical: ${analysis.signal.technical.summary}")
                    Text("Fundamental: ${analysis.signal.fundamental.summary}")
                    Text("Reasoning: ${analysis.signal.reasoning}")
                    Text("Confidence: ${analysis.signal.confidence}")
                    Text("Published event: ${analysis.publishedSignal?.eventId ?: "not published"}")

                    Text("Buy Options")
                    analysis.signal.tradePlan.buyOptions.forEach { option ->
                        Text(
                            "Entry ${option.entry} | SL ${option.stopLoss} | TP ${option.takeProfit} | RR ${option.riskReward}"
                        )
                    }

                    Text("Sell Options")
                    analysis.signal.tradePlan.sellOptions.forEach { option ->
                        Text(
                            "Entry ${option.entry} | SL ${option.stopLoss} | TP ${option.takeProfit} | RR ${option.riskReward}"
                        )
                    }

                    Text("Risk Warnings")
                    if (analysis.signal.risk.warnings.isEmpty()) {
                        Text("No warnings")
                    } else {
                        analysis.signal.risk.warnings.forEach { warning -> Text(warning) }
                    }
                }
            }
        }

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Settings", style = MaterialTheme.typography.titleMedium)
                OutlinedTextField(
                    value = blossomServer,
                    onValueChange = { blossomServer = it },
                    label = { Text("Blossom NIP-96 server") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = relayInput,
                    onValueChange = { relayInput = it },
                    label = { Text("Relays (comma separated)") },
                    modifier = Modifier.fillMaxWidth()
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = {
                        scope.launch {
                            settingsRepository.update {
                                val nextTheme = when (it.themeMode) {
                                    ThemeMode.SYSTEM -> ThemeMode.LIGHT
                                    ThemeMode.LIGHT -> ThemeMode.DARK
                                    ThemeMode.DARK -> ThemeMode.HIGH_CONTRAST
                                    ThemeMode.HIGH_CONTRAST -> ThemeMode.SYSTEM
                                }
                                it.copy(themeMode = nextTheme)
                            }
                        }
                    }) {
                        Text("Theme: ${settings.themeMode}")
                    }

                    Button(onClick = {
                        scope.launch {
                            settingsRepository.update {
                                it.copy(
                                    blossomServer = blossomServer,
                                    preferredRelays = relayInput.split(',').map(String::trim).filter(String::isNotBlank)
                                )
                            }
                        }
                    }) {
                        Text("Save Settings")
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Checkbox(
                        checked = settings.showLiquidityZones,
                        onCheckedChange = { checked ->
                            scope.launch {
                                settingsRepository.update { it.copy(showLiquidityZones = checked) }
                            }
                        }
                    )
                    Text("Show liquidity overlays")
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Checkbox(
                        checked = settings.showStructureBreaks,
                        onCheckedChange = { checked ->
                            scope.launch {
                                settingsRepository.update { it.copy(showStructureBreaks = checked) }
                            }
                        }
                    )
                    Text("Show structure overlays")
                }
            }
        }
    }
}

private fun loadScreenshotPayload(path: String): ScreenshotPayload {
    if (path.isBlank()) {
        return ScreenshotPayload(
            name = "demo-screenshot.png",
            mimeType = "image/png",
            bytes = pseudoImageBytes("demo-screenshot")
        )
    }

    val file = File(path)
    return if (file.exists()) {
        ScreenshotPayload(
            name = file.name,
            mimeType = guessMimeType(file.name),
            bytes = Files.readAllBytes(file.toPath())
        )
    } else {
        ScreenshotPayload(
            name = "fallback-${file.name.ifBlank { "screenshot.png" }}",
            mimeType = "image/png",
            bytes = pseudoImageBytes(path)
        )
    }
}

private fun guessMimeType(fileName: String): String {
    return when {
        fileName.endsWith(".png", ignoreCase = true) -> "image/png"
        fileName.endsWith(".jpg", ignoreCase = true) ||
            fileName.endsWith(".jpeg", ignoreCase = true) -> "image/jpeg"

        else -> "application/octet-stream"
    }
}
