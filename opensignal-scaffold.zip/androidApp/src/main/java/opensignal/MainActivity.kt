package opensignal

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import opensignal.ai.pipeline.OpenSignalVisionAnalyzer
import opensignal.ai.pipeline.RuleBasedFundamentalAnalyzer
import opensignal.blossom.nip96_client.Nip96ServerConfig
import opensignal.blossom.upload_service.BlossomUploadService
import opensignal.charts.TradingChart
import opensignal.domain.AnalyzeScreenshotUseCase
import opensignal.domain.OpenSignalController
import opensignal.domain.ScreenshotUploader
import opensignal.domain.parseTimeframeOrDefault
import opensignal.domain.pseudoImageBytes
import opensignal.models.ScreenshotPayload
import opensignal.nostr.NostrClient
import opensignal.settings.InMemorySettingsRepository
import opensignal.settings.SettingsRepository
import opensignal.settings.ThemeMode

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            AndroidAppShell()
        }
    }
}

private class SettingsAwareUploader(
    private val settingsRepository: SettingsRepository
) : ScreenshotUploader {
    override suspend fun upload(payload: ScreenshotPayload) = BlossomUploadService(
        Nip96ServerConfig(baseUrl = settingsRepository.settings.value.blossomServer)
    ).upload(payload)
}

@Composable
private fun AndroidAppShell() {
    val settingsRepository = remember { InMemorySettingsRepository() }
    val nostrClient = remember { NostrClient() }
    val screenshotUploader = remember { SettingsAwareUploader(settingsRepository) }
    val analyzer = remember { OpenSignalVisionAnalyzer() }
    val fundamental = remember { RuleBasedFundamentalAnalyzer() }
    val useCase = remember {
        AnalyzeScreenshotUseCase(
            screenshotUploader = screenshotUploader,
            chartVisionAnalyzer = analyzer,
            fundamentalAnalyzer = fundamental,
            signalPublisher = nostrClient
        )
    }
    val controller = remember {
        OpenSignalController(
            authGateway = nostrClient,
            analyzeUseCase = useCase,
            settingsRepository = settingsRepository
        )
    }

    val settings by settingsRepository.settings.collectAsState()
    val colorScheme = when (settings.themeMode) {
        ThemeMode.DARK, ThemeMode.HIGH_CONTRAST -> darkColorScheme()
        else -> lightColorScheme()
    }

    MaterialTheme(colorScheme = colorScheme) {
        AndroidCopilotScreen(
            controller = controller,
            settingsRepository = settingsRepository
        )
    }
}

@Composable
private fun AndroidCopilotScreen(
    controller: OpenSignalController,
    settingsRepository: SettingsRepository
) {
    val scope = rememberCoroutineScope()
    val state by controller.state.collectAsState()
    val settings by settingsRepository.settings.collectAsState()

    var nsec by remember { mutableStateOf("") }
    var signerUri by remember { mutableStateOf("bunker://nostr-signer") }
    var symbol by remember { mutableStateOf("BTCUSDT") }
    var timeframe by remember { mutableStateOf("H1") }
    var screenshotDescriptor by remember { mutableStateOf("phone-capture") }
    var accountBalance by remember { mutableStateOf("10000") }
    var riskPercent by remember { mutableStateOf("1") }
    var leverage by remember { mutableStateOf("3") }
    var context by remember { mutableStateOf("Scalp setup") }
    var blossomServer by remember { mutableStateOf(settings.blossomServer) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("OpenSignal Mobile Copilot", style = MaterialTheme.typography.titleLarge)

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Nostr Login")
                OutlinedTextField(
                    value = nsec,
                    onValueChange = { nsec = it },
                    label = { Text("nsec") },
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = {
                        scope.launch {
                            controller.loginWithNsec(nsec, settings.preferredRelays.firstOrNull())
                        }
                    }) {
                        Text("Use nsec")
                    }
                    Button(onClick = {
                        scope.launch {
                            controller.loginWithExternalSigner(signerUri)
                        }
                    }) {
                        Text("External signer")
                    }
                }
                OutlinedTextField(
                    value = signerUri,
                    onValueChange = { signerUri = it },
                    label = { Text("Signer URI") },
                    modifier = Modifier.fillMaxWidth()
                )
                Text("Session: ${state.authSession?.pubkey ?: "None"}")
            }
        }

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Analyze Screenshot")
                OutlinedTextField(
                    value = symbol,
                    onValueChange = { symbol = it },
                    label = { Text("Symbol") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = timeframe,
                    onValueChange = { timeframe = it },
                    label = { Text("Timeframe") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = screenshotDescriptor,
                    onValueChange = { screenshotDescriptor = it },
                    label = { Text("Screenshot descriptor") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = context,
                    onValueChange = { context = it },
                    label = { Text("Context") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = accountBalance,
                    onValueChange = { accountBalance = it },
                    label = { Text("Balance") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = riskPercent,
                    onValueChange = { riskPercent = it },
                    label = { Text("Risk %") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = leverage,
                    onValueChange = { leverage = it },
                    label = { Text("Leverage") },
                    modifier = Modifier.fillMaxWidth()
                )

                Button(onClick = {
                    scope.launch {
                        controller.analyzeScreenshot(
                            symbol = symbol,
                            timeframe = parseTimeframeOrDefault(timeframe),
                            screenshot = ScreenshotPayload(
                                name = "android-screenshot.png",
                                mimeType = "image/png",
                                bytes = pseudoImageBytes(screenshotDescriptor)
                            ),
                            accountBalance = accountBalance.toDoubleOrNull() ?: 10_000.0,
                            riskPercent = riskPercent.toDoubleOrNull() ?: 1.0,
                            leverage = leverage.toDoubleOrNull() ?: 3.0,
                            userContext = context
                        )
                    }
                }) {
                    Text(if (state.isLoading) "Analyzing..." else "Analyze")
                }

                state.error?.let { Text("Error: $it") }
            }
        }

        state.latestAnalysis?.let { analysis ->
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    TradingChart(
                        technical = analysis.signal.technical,
                        tradePlan = analysis.signal.tradePlan,
                        showLiquidity = settings.showLiquidityZones,
                        showStructure = settings.showStructureBreaks,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text("Technical: ${analysis.signal.technical.summary}")
                    Text("Fundamental: ${analysis.signal.fundamental.summary}")
                    Text("Buy options: ${analysis.signal.tradePlan.buyOptions.size}")
                    Text("Sell options: ${analysis.signal.tradePlan.sellOptions.size}")
                    Text("Published: ${analysis.publishedSignal?.eventId ?: "No"}")
                }
            }
        }

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Settings")
                OutlinedTextField(
                    value = blossomServer,
                    onValueChange = { blossomServer = it },
                    label = { Text("Blossom server") },
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Checkbox(
                        checked = settings.showLiquidityZones,
                        onCheckedChange = { checked ->
                            scope.launch {
                                settingsRepository.update { it.copy(showLiquidityZones = checked) }
                            }
                        }
                    )
                    Text("Show liquidity")
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Checkbox(
                        checked = settings.showStructureBreaks,
                        onCheckedChange = { checked ->
                            scope.launch {
                                settingsRepository.update { it.copy(showStructureBreaks = checked) }
                            }
                        }
                    )
                    Text("Show structure")
                }
                Button(onClick = {
                    scope.launch {
                        settingsRepository.update {
                            val nextTheme = when (it.themeMode) {
                                ThemeMode.SYSTEM -> ThemeMode.LIGHT
                                ThemeMode.LIGHT -> ThemeMode.DARK
                                ThemeMode.DARK -> ThemeMode.HIGH_CONTRAST
                                ThemeMode.HIGH_CONTRAST -> ThemeMode.SYSTEM
                            }
                            it.copy(themeMode = nextTheme, blossomServer = blossomServer)
                        }
                    }
                }) {
                    Text("Theme: ${settings.themeMode}")
                }
            }
        }
    }
}
