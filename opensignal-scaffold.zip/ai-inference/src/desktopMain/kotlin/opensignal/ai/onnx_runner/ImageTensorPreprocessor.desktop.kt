package opensignal.ai.onnx_runner

import java.awt.RenderingHints
import java.awt.image.BufferedImage
import java.io.ByteArrayInputStream
import javax.imageio.ImageIO

actual object ImageTensorPreprocessor {

    actual fun toChwFloat(
        imageBytes: ByteArray,
        targetWidth: Int,
        targetHeight: Int
    ): FloatArray {
        val image = ImageIO.read(ByteArrayInputStream(imageBytes))
            ?: error("Failed to decode screenshot bytes as image")

        val resized = BufferedImage(targetWidth, targetHeight, BufferedImage.TYPE_INT_RGB)
        val graphics = resized.createGraphics()
        graphics.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR)
        graphics.drawImage(image, 0, 0, targetWidth, targetHeight, null)
        graphics.dispose()

        val planeSize = targetWidth * targetHeight
        val output = FloatArray(planeSize * 3)

        var index = 0
        for (y in 0 until targetHeight) {
            for (x in 0 until targetWidth) {
                val rgb = resized.getRGB(x, y)
                val r = (rgb shr 16) and 0xFF
                val g = (rgb shr 8) and 0xFF
                val b = rgb and 0xFF

                output[index] = r / 255f
                output[index + planeSize] = g / 255f
                output[index + planeSize * 2] = b / 255f
                index++
            }
        }

        return output
    }
}
