package opensignal.ai.onnx_runner

import android.graphics.Bitmap
import android.graphics.BitmapFactory

actual object ImageTensorPreprocessor {

    actual fun toChwFloat(
        imageBytes: ByteArray,
        targetWidth: Int,
        targetHeight: Int
    ): FloatArray {
        val decoded = BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.size)
            ?: error("Failed to decode screenshot bytes as Bitmap")

        val scaled = Bitmap.createScaledBitmap(decoded, targetWidth, targetHeight, true)
        if (scaled != decoded) {
            decoded.recycle()
        }

        val pixels = IntArray(targetWidth * targetHeight)
        scaled.getPixels(pixels, 0, targetWidth, 0, 0, targetWidth, targetHeight)

        val planeSize = targetWidth * targetHeight
        val output = FloatArray(planeSize * 3)

        var index = 0
        pixels.forEach { pixel ->
            val r = (pixel shr 16) and 0xFF
            val g = (pixel shr 8) and 0xFF
            val b = pixel and 0xFF

            output[index] = r / 255f
            output[index + planeSize] = g / 255f
            output[index + planeSize * 2] = b / 255f
            index++
        }

        scaled.recycle()
        return output
    }
}
